// This is a manifest file that will include all the files listed below.
//
// WARNING: THE FIRST BLANK LINE MARKS THE END OF WHAT'S TO BE PROCESSED, ANY BLANK LINE SHOULD
// GO AFTER THE REQUIRES BELOW.
//
//= require jquery_1_8_3.min
//= require application2
//= require jquery.form
//= require contact_us
//= require article/article.js
//= require article/bjqs-1.3.min.js
//= require reviews/jquery.nanoscroller.min
//= require article/jquery.scroolUp
//

